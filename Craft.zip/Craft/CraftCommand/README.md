# CraftCommand
 Plugin permetant d'accéder à l'interface de craft via une commande.
